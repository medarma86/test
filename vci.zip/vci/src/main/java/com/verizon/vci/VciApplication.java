package com.verizon.vci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VciApplication {

	public static void main(String[] args) {
		SpringApplication.run(VciApplication.class, args);
	}

}
