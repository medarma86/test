package com.verizon.vci;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VciApplicationTests {

	@Test
	void contextLoads() {
	}

}
